package co.edu.unbosque.util;

public class CellPhoneFormatException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CellPhoneFormatException(String mesage) {
		super(mesage);
	}
}
