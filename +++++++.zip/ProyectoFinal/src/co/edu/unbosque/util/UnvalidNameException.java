package co.edu.unbosque.util;

public class UnvalidNameException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UnvalidNameException(String mesage) {
		super(mesage);
	}	
	
	
}
